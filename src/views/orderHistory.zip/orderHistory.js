
import {useState, useEffect} from 'react'
import '../css/orderHistory.css';
import user from '../assets/user.png';
import {  useDispatch,useSelector } from 'react-redux';
//import { useHistory } from 'react-router-dom'
//import actions from '../actions/orderAction'
import OrderItem from '../components/OrderItem';

//Function calling
function OrderHistory() {
  // const offers = useSelector((state) => { return state.offers})
  const userId = useSelector((state) => { return state.userId })
 
  const [orderHistory, setOrderHistory] = useState()
  const dispatch = useDispatch()
  
  //getting order using api,response,result
     
    async function getOrderHistory() {
      
      //let url = 'http://localhost:8000/api/order/7892'
    
     let url = `http://localhost:8000/api/order/+orderID`
        console.log("userId",userId)
      const response = await fetch(url)
      const data = await response.json()
      
      //here is the condition for orderhistory
      
      if (data ) {
        console.log('data==:', data.orderHistory)
        setOrderHistory(data.orderHistory)
        
        
         } 
        
      }

    
 useEffect(() => {
 
    getOrderHistory()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch])
  //console.log(orderhistory)

  return (
    <section className="orderHistory">
      <img src={user} alt="Profilepic" />
      <h1 className="orderuserid">{userId}</h1>
       
      <p className="orderemail">Priyakolukuluri@hotmail.com</p>
      <ul className="order-wrap">
        {
          orderHistory && orderHistory.map((post) => {
            return (
              <OrderItem orderlist={post.userId} key={`index-${ post.id }`}
  
  
              />
            )
   
 
          })}
      </ul>
    </section>
  )
}
  export default OrderHistory;